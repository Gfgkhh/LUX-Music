package com.luxmusic

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

private val Ink = Color(0xFF080B1B)
private val Purple = Color(0xFF9B4DFF)
private val Cyan = Color(0xFF16D9F5)
private val Muted = Color(0xFFAAA9C4)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) setContent { LuxApp() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            setContent { LuxApp() }
        } else {
            setContent {
                PermissionScreen {
                    permissionLauncher.launch(permission)
                }
            }
        }
    }
}

@Composable
private fun PermissionScreen(onAllow: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Ink), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Icon(Icons.Default.Headphones, null, tint = Cyan, modifier = Modifier.size(64.dp))
            Text("LUX Music", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("نحتاج إذن الوصول إلى ملفات الصوت لعرض موسيقاك", color = Muted)
            Button(onClick = onAllow, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                Text("السماح بالوصول")
            }
        }
    }
}

@Composable
private fun LuxApp(vm: MusicViewModel = viewModel()) {
    val songs by vm.songs.collectAsState()
    val current by vm.currentSong.collectAsState()
    val playing by vm.isPlaying.collectAsState()
    val speed by vm.speed.collectAsState()
    val pitch by vm.pitch.collectAsState()
    val spatial by vm.spatialEnabled.collectAsState()

    LaunchedEffect(Unit) { vm.loadSongs() }

    Box(Modifier.fillMaxSize().background(
        Brush.linearGradient(listOf(Color(0xFF111638), Ink, Color(0xFF170C2D)))
    )) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 22.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("LUX", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("FEEL THE SOUND", color = Cyan, fontSize = 10.sp, letterSpacing = 3.sp)
                }
                IconButton(onClick = { vm.loadSongs() }) {
                    Icon(Icons.Default.Refresh, "تحديث المكتبة", tint = Color.White)
                }
            }

            GlassPanel(Modifier.fillMaxWidth()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth().padding(18.dp)) {
                    Box(
                        Modifier.size(190.dp).clip(CircleShape).background(
                            Brush.linearGradient(listOf(Purple, Color(0xFF171D4B), Cyan))
                        ), contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Album, null, tint = Color.White, modifier = Modifier.size(112.dp))
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(current?.title ?: "لا توجد أغنية قيد التشغيل", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(current?.artist ?: "اختر أغنية من مكتبتك", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                        IconButton(onClick = { vm.previous() }) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                        FilledIconButton(onClick = { vm.togglePlay() }, modifier = Modifier.size(64.dp),
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Purple)) {
                            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp))
                        }
                        IconButton(onClick = { vm.next() }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text("مكتبة الموسيقى  •  ${songs.size} ملف", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (songs.isEmpty()) {
                Text("لم نعثر على ملفات صوتية بعد. أضف ملفات إلى هاتفك ثم اضغط تحديث.", color = Muted, modifier = Modifier.padding(12.dp))
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(songs, key = { it.id }) { song ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                                .background(Color.White.copy(alpha = 0.07f))
                                .clickable { vm.play(song) }.padding(13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.MusicNote, null, tint = Cyan, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(song.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(song.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
                            }
                            if (current?.id == song.id) Icon(Icons.Default.Equalizer, null, tint = Purple)
                        }
                    }
                }
            }

            GlassPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("استوديو الصوت", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("8D", color = Cyan, fontWeight = FontWeight.Bold)
                        Switch(checked = spatial, onCheckedChange = vm::setSpatial, colors = SwitchDefaults.colors(checkedThumbColor = Cyan))
                    }
                    Text("السرعة ${"%.2f".format(speed)}x", color = Color.White, fontSize = 13.sp)
                    Slider(value = speed, onValueChange = vm::setSpeed, valueRange = 0.5f..2f,
                        colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Purple))
                    Text("النبرة ${"%.1f".format(pitch)} نصف نغمة", color = Color.White, fontSize = 13.sp)
                    Slider(value = pitch, onValueChange = vm::setPitch, valueRange = -12f..12f,
                        colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Purple))
                    Text("ملاحظة: مؤثر 8D وطبقة الصوت في هذه النسخة أولية، وسيتم ربطهما بمعالجة صوتية فعلية في المرحلة التالية.", color = Muted, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(26.dp))
        .background(Color.White.copy(alpha = 0.075f))
        .padding(1.dp)
        .clip(RoundedCornerShape(25.dp))
        .background(Color(0xFF171A35).copy(alpha = 0.82f))) { content() }
}
