package com.luxmusic

import android.app.Application
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class Song(val id: Long, val title: String, val artist: String, val uri: String)

class MusicViewModel(app: Application) : AndroidViewModel(app) {
    private val player = ExoPlayer.Builder(app).build()
    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs
    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying
    private val _speed = MutableStateFlow(1f)
    val speed: StateFlow<Float> = _speed
    private val _pitch = MutableStateFlow(0f)
    val pitch: StateFlow<Float> = _pitch
    private val _spatialEnabled = MutableStateFlow(false)
    val spatialEnabled: StateFlow<Boolean> = _spatialEnabled

    fun loadSongs() {
        val result = mutableListOf<Song>()
        val resolver = getApplication<Application>().contentResolver
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        resolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = android.content.ContentUris.withAppendedId(collection, id).toString()
                result += Song(id, cursor.getString(titleCol) ?: "Unknown",
                    cursor.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "Unknown artist", uri)
            }
        }
        _songs.value = result
    }

    fun play(song: Song) {
        val index = _songs.value.indexOfFirst { it.id == song.id }
        if (index < 0) return
        _currentSong.value = song
        player.setMediaItems(_songs.value.map { MediaItem.fromUri(it.uri) }, index, 0L)
        player.prepare()
        player.play()
        _isPlaying.value = true
        applyPlaybackParameters()
    }

    fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
        _isPlaying.value = player.isPlaying
    }

    fun next() { player.seekToNextMediaItem(); updateCurrent() }
    fun previous() { player.seekToPreviousMediaItem(); updateCurrent() }

    private fun updateCurrent() {
        val index = player.currentMediaItemIndex
        _currentSong.value = _songs.value.getOrNull(index)
    }

    fun setSpeed(value: Float) {
        _speed.value = value
        applyPlaybackParameters()
    }

    fun setPitch(semitones: Float) {
        _pitch.value = semitones
        applyPlaybackParameters()
    }

    private fun applyPlaybackParameters() {
        // Varispeed: speed and pitch move together. Pitch control adds an independent semitone offset.
        val pitchFactor = _speed.value * Math.pow(2.0, (_pitch.value / 12.0).toDouble()).toFloat()
        player.playbackParameters = PlaybackParameters(_speed.value, pitchFactor)
    }

    fun setSpatial(enabled: Boolean) {
        _spatialEnabled.value = enabled
        // Spatial 8D DSP is intentionally a follow-up stage; this toggle is UI-only in MVP.
    }

    override fun onCleared() {
        player.release()
        super.onCleared()
    }
}
